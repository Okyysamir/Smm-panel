-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 30, 2021 at 03:06 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pp`
--

-- --------------------------------------------------------

--
-- Table structure for table `bank_accounts`
--

CREATE TABLE `bank_accounts` (
  `id` int(11) NOT NULL,
  `bank_name` varchar(225) NOT NULL,
  `bank_sube` varchar(225) NOT NULL,
  `bank_hesap` varchar(225) NOT NULL,
  `bank_iban` text NOT NULL,
  `bank_alici` varchar(225) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `category_id` int(11) NOT NULL,
  `category_name` text COLLATE utf8mb4_bin NOT NULL,
  `category_line` double NOT NULL,
  `category_type` enum('1','2') CHARACTER SET utf8 NOT NULL DEFAULT '2',
  `category_secret` enum('1','2') COLLATE utf8mb4_bin NOT NULL DEFAULT '2',
  `category_icon` text COLLATE utf8mb4_bin NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`category_id`, `category_name`, `category_line`, `category_type`, `category_secret`, `category_icon`) VALUES
(1, 'Test Service', 1, '2', '2', ' ');

-- --------------------------------------------------------

--
-- Table structure for table `clients`
--

CREATE TABLE `clients` (
  `client_id` int(11) NOT NULL,
  `name` varchar(225) NOT NULL,
  `email` varchar(225) NOT NULL,
  `username` varchar(225) NOT NULL,
  `password` text NOT NULL,
  `telephone` varchar(225) DEFAULT NULL,
  `balance` double NOT NULL DEFAULT 0,
  `balance_type` enum('1','2') NOT NULL DEFAULT '2',
  `debit_limit` double DEFAULT NULL,
  `spent` double NOT NULL DEFAULT 0,
  `register_date` datetime NOT NULL,
  `login_date` datetime DEFAULT NULL,
  `login_ip` varchar(225) DEFAULT NULL,
  `apikey` text NOT NULL,
  `tel_type` enum('1','2') NOT NULL DEFAULT '1' COMMENT '2 -> ON, 1 -> OFF',
  `email_type` enum('1','2') NOT NULL DEFAULT '1' COMMENT '2 -> ON, 1 -> OFF',
  `client_type` enum('1','2') NOT NULL DEFAULT '2' COMMENT '2 -> ON, 1 -> OFF',
  `access` text DEFAULT NULL,
  `lang` varchar(255) NOT NULL DEFAULT 'tr',
  `timezone` double NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `clients`
--

INSERT INTO `clients` (`client_id`, `name`, `email`, `username`, `password`, `telephone`, `balance`, `balance_type`, `debit_limit`, `spent`, `register_date`, `login_date`, `login_ip`, `apikey`, `tel_type`, `email_type`, `client_type`, `access`, `lang`, `timezone`) VALUES
(99, 'admin', 'admin@smmpanels.store', 'admin', 'bb530de17aa1d30bc3bdb5a9e8012154', '1234567890', 180, '2', NULL, 669.238, '2021-01-01 12:39:21', '2021-01-30 19:17:59', '::1', '09ede86c319db47129292d1d6a8ede96', '1', '1', '2', '{\"admin_access\":\"1\",\"users\":\"1\",\"orders\":\"1\",\"subscriptions\":\"1\",\"dripfeed\":\"1\",\"services\":\"1\",\"payments\":\"1\",\"tickets\":\"1\",\"reports\":\"1\",\"general_settings\":\"1\",\"pages\":\"1\",\"payments_settings\":\"1\",\"bank_accounts\":\"1\",\"payments_bonus\":\"1\",\"alert_settings\":\"1\",\"providers\":\"1\",\"themes\":\"1\",\"admins\":\"1\",\"language\":\"1\",\"meta\":\"1\",\"proxy\":\"1\",\"kuponlar\":\"1\"}', 'en', 9000);

-- --------------------------------------------------------

--
-- Table structure for table `clients_category`
--

CREATE TABLE `clients_category` (
  `id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `clients_price`
--

CREATE TABLE `clients_price` (
  `id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL,
  `service_price` double NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `clients_service`
--

CREATE TABLE `clients_service` (
  `id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `client_report`
--

CREATE TABLE `client_report` (
  `id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `action` text NOT NULL,
  `report_ip` varchar(225) NOT NULL,
  `report_date` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `client_report`
--

INSERT INTO `client_report` (`id`, `client_id`, `action`, `report_ip`, `report_date`) VALUES
(4, 162, 'Yönetici girişi yapıldı.', '157.44.218.6', '2021-01-01 13:36:07'),
(5, 162, 'Yönetici girişi yapıldı.', '157.44.218.6', '2021-01-01 13:41:19'),
(9, 162, 'Üye girişi yapıldı.', '58.145.184.226', '2021-01-01 16:35:18'),
(16, 162, 'Üye girişi yapıldı.', '8.38.148.165', '2021-01-02 23:42:38'),
(17, 162, 'Yönetici girişi yapıldı.', '103.250.165.57', '2021-01-02 23:43:32'),
(19, 162, 'Yönetici girişi yapıldı.', '106.210.210.171', '2021-01-03 00:02:30'),
(20, 162, 'Yönetici girişi yapıldı.', '103.250.165.57', '2021-01-03 00:13:48'),
(21, 162, 'Yönetici girişi yapıldı.', '103.250.165.57', '2021-01-03 00:21:47'),
(22, 162, 'Üye girişi yapıldı.', '157.46.215.105', '2021-01-03 18:28:30'),
(23, 162, 'Üye girişi yapıldı.', '157.42.251.215', '2021-01-03 18:37:03'),
(24, 163, 'Kullanıcı kaydı yapıldı.', '223.188.112.58', '2021-01-03 19:03:57'),
(25, 163, 'Üye girişi yapıldı.', '223.188.112.58', '2021-01-03 19:04:10'),
(26, 164, 'Kullanıcı kaydı yapıldı.', '27.97.189.110', '2021-01-03 22:54:41'),
(27, 164, 'Üye girişi yapıldı.', '27.97.189.110', '2021-01-03 22:54:57'),
(28, 162, 'Yönetici girişi yapıldı.', '157.44.209.205', '2021-01-04 13:34:50'),
(29, 165, 'Kullanıcı kaydı yapıldı.', '124.253.166.217', '2021-01-04 18:36:15'),
(30, 165, 'Üye girişi yapıldı.', '124.253.166.217', '2021-01-04 18:36:22'),
(31, 162, 'Yönetici girişi yapıldı.', '124.253.166.217', '2021-01-04 18:37:49'),
(32, 166, 'Kullanıcı kaydı yapıldı.', '157.38.78.52', '2021-01-04 18:44:24'),
(33, 166, 'Üye girişi yapıldı.', '157.38.78.52', '2021-01-04 18:44:36'),
(34, 167, 'Kullanıcı kaydı yapıldı.', '103.66.214.153', '2021-01-04 19:46:28'),
(35, 162, 'Üye girişi yapıldı.', '103.66.214.153', '2021-01-04 19:47:30'),
(36, 168, 'Kullanıcı kaydı yapıldı.', '119.160.65.195', '2021-01-05 10:06:17'),
(37, 168, 'Üye girişi yapıldı.', '119.160.65.195', '2021-01-05 10:06:29'),
(38, 162, 'Yönetici girişi yapıldı.', '119.160.65.195', '2021-01-05 10:08:03'),
(39, 162, 'Yönetici girişi yapıldı.', '103.127.20.158', '2021-01-05 21:26:51'),
(40, 168, 'Üye girişi yapıldı.', '182.186.200.119', '2021-01-06 12:04:24'),
(41, 162, 'Yönetici girişi yapıldı.', '182.186.184.153', '2021-01-07 22:39:21'),
(42, 162, 'Üye girişi yapıldı.', '223.184.201.195', '2021-01-08 18:58:05'),
(43, 162, 'Üye girişi yapıldı.', '223.184.201.195', '2021-01-08 19:04:44'),
(44, 162, 'Üye girişi yapıldı.', '157.42.25.191', '2021-01-09 11:51:48'),
(45, 162, 'Yönetici girişi yapıldı.', '157.42.25.191', '2021-01-09 11:55:26'),
(46, 162, 'Üye girişi yapıldı.', '202.142.119.171', '2021-01-09 19:14:34'),
(47, 162, 'Üye girişi yapıldı.', '111.119.187.51', '2021-01-09 22:15:22'),
(50, 162, 'Üye girişi yapıldı.', '223.189.57.97', '2021-01-12 12:08:25'),
(51, 166, 'Üye girişi yapıldı.', '157.38.13.95', '2021-01-15 00:16:13'),
(52, 162, 'Yönetici girişi yapıldı.', '49.15.82.148', '2021-01-15 16:19:46'),
(54, 162, 'Yönetici girişi yapıldı.', '157.46.137.139', '2021-01-16 02:37:17'),
(57, 99, 'Üye girişi yapıldı.', '137.97.94.239', '2021-01-26 17:19:38'),
(58, 99, 'Üye girişi yapıldı.', '137.97.94.239', '2021-01-26 17:56:51'),
(59, 169, 'Kullanıcı kaydı yapıldı.', '212.156.147.70', '2021-01-26 17:59:51'),
(60, 169, 'Üye girişi yapıldı.', '212.156.147.70', '2021-01-26 18:00:05'),
(61, 170, 'Üye girişi yapıldı.', '137.97.94.239', '2021-01-26 18:00:49'),
(62, 170, 'Yönetici girişi yapıldı.', '212.156.147.70', '2021-01-26 18:02:33'),
(63, 170, 'Yönetici girişi yapıldı.', '212.156.147.70', '2021-01-26 18:02:34'),
(64, 170, 'Üye girişi yapıldı.', '88.236.65.0', '2021-01-26 18:04:27'),
(65, 170, 'Üye girişi yapıldı.', '188.253.231.64', '2021-01-26 18:10:23'),
(66, 99, 'Üye girişi yapıldı.', '137.97.94.239', '2021-01-26 18:24:37'),
(67, 99, 'Yeni destek talebi oluşturuldu #3', '137.97.94.239', '2021-01-26 21:58:34'),
(68, 99, 'Yeni destek talebi oluşturuldu #4', '137.97.94.239', '2021-01-26 22:08:51'),
(69, 99, 'Üye girişi yapıldı.', '157.34.76.180', '2021-01-27 13:16:10'),
(70, 170, 'Üye girişi yapıldı.', '157.34.76.180', '2021-01-27 13:28:52'),
(71, 99, 'Yönetici girişi yapıldı.', '137.97.64.174', '2021-01-27 13:29:47'),
(72, 170, 'Yönetici girişi yapıldı.', '157.34.76.180', '2021-01-27 13:30:39'),
(73, 170, 'Yönetici girişi yapıldı.', '137.97.64.174', '2021-01-27 16:27:13'),
(74, 99, 'Yönetici girişi yapıldı.', '137.97.64.174', '2021-01-27 16:28:30'),
(75, 99, 'Yönetici girişi yapıldı.', '137.97.64.174', '2021-01-27 16:29:03'),
(76, 99, 'Yönetici girişi yapıldı.', '::1', '2021-01-30 18:45:46'),
(77, 99, 'Yönetici girişi yapıldı.', '::1', '2021-01-30 18:50:51'),
(78, 99, 'Yeni destek talebi oluşturuldu #5', '::1', '2021-01-30 18:54:36'),
(79, 99, 'Destek talebine yanıt verildi #5', '::1', '2021-01-30 18:54:40'),
(80, 99, '0 TL tutarında yeni sipariş geçildi #.', '::1', '2021-01-30 18:54:59'),
(81, 99, '0 TL tutarında yeni sipariş geçildi #.', '::1', '2021-01-30 18:55:50'),
(82, 99, '0 TL tutarında yeni sipariş geçildi #.', '::1', '2021-01-30 18:55:54'),
(83, 99, '0 TL tutarında yeni sipariş geçildi #.', '::1', '2021-01-30 18:57:09'),
(84, 99, 'Üye girişi yapıldı.', '::1', '2021-01-30 18:57:19'),
(85, 99, 'Kullanıcı parolası değiştirildi', '::1', '2021-01-30 19:17:43'),
(86, 99, 'Üye girişi yapıldı.', '::1', '2021-01-30 19:17:59');

-- --------------------------------------------------------

--
-- Table structure for table `kuponlar`
--

CREATE TABLE `kuponlar` (
  `id` int(11) NOT NULL,
  `kuponadi` varchar(255) NOT NULL,
  `adet` int(11) NOT NULL,
  `tutar` double NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `kupon_kullananlar`
--

CREATE TABLE `kupon_kullananlar` (
  `id` int(11) NOT NULL,
  `uye_id` int(11) NOT NULL,
  `kuponadi` varchar(255) NOT NULL,
  `tutar` double NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `languages`
--

CREATE TABLE `languages` (
  `id` int(11) NOT NULL,
  `language_name` varchar(225) NOT NULL,
  `language_code` varchar(225) NOT NULL,
  `language_type` enum('2','1') NOT NULL DEFAULT '2',
  `default_language` enum('0','1') NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `languages`
--

INSERT INTO `languages` (`id`, `language_name`, `language_code`, `language_type`, `default_language`) VALUES
(1, 'Türkçe', 'tr', '1', '0'),
(2, 'English', 'en', '2', '1');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL,
  `api_orderid` int(11) NOT NULL DEFAULT 0,
  `order_error` text NOT NULL,
  `order_detail` text DEFAULT NULL,
  `order_api` int(11) NOT NULL DEFAULT 0,
  `api_serviceid` int(11) NOT NULL DEFAULT 0,
  `api_charge` double NOT NULL DEFAULT 0,
  `api_currencycharge` double DEFAULT 1,
  `order_profit` double NOT NULL,
  `order_quantity` double NOT NULL,
  `order_extras` text NOT NULL,
  `order_charge` double NOT NULL,
  `dripfeed` enum('1','2','3') DEFAULT '1' COMMENT '2 -> ON, 1 -> OFF',
  `dripfeed_id` double NOT NULL DEFAULT 0,
  `subscriptions_id` double NOT NULL DEFAULT 0,
  `subscriptions_type` enum('1','2') NOT NULL DEFAULT '1' COMMENT '2 -> ON, 1 -> OFF',
  `dripfeed_totalcharges` double DEFAULT NULL,
  `dripfeed_runs` double DEFAULT NULL,
  `dripfeed_delivery` double NOT NULL DEFAULT 0,
  `dripfeed_interval` double DEFAULT NULL,
  `dripfeed_totalquantity` double DEFAULT NULL,
  `dripfeed_status` enum('active','completed','canceled') NOT NULL DEFAULT 'active',
  `order_url` text NOT NULL,
  `order_start` double NOT NULL DEFAULT 0,
  `order_finish` double NOT NULL DEFAULT 0,
  `order_remains` double NOT NULL DEFAULT 0,
  `order_create` datetime NOT NULL,
  `order_status` enum('pending','inprogress','completed','partial','processing','canceled') NOT NULL DEFAULT 'pending',
  `subscriptions_status` enum('active','paused','completed','canceled','expired','limit') NOT NULL DEFAULT 'active',
  `subscriptions_username` text DEFAULT NULL,
  `subscriptions_posts` double DEFAULT NULL,
  `subscriptions_delivery` double NOT NULL DEFAULT 0,
  `subscriptions_delay` double DEFAULT NULL,
  `subscriptions_min` double DEFAULT NULL,
  `subscriptions_max` double DEFAULT NULL,
  `subscriptions_expiry` date DEFAULT NULL,
  `last_check` datetime NOT NULL,
  `order_where` enum('site','api') NOT NULL DEFAULT 'site'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

CREATE TABLE `pages` (
  `page_id` int(11) NOT NULL,
  `page_name` varchar(225) NOT NULL,
  `page_get` varchar(225) NOT NULL,
  `page_content` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pages`
--

INSERT INTO `pages` (`page_id`, `page_name`, `page_get`, `page_content`) VALUES
(1, 'Login', 'auth', ''),
(2, 'New Order', 'neworder', '<div class=\"alert alert-danger\" role=\"alert\">\r\n  100% Drop in Bot Followers</div>'),
(3, 'Services', 'services', ''),
(4, 'Add Funds', 'addfunds', '<p><br></p>'),
(5, 'Tickets', 'tickets', '<p><font style=\"vertical-align: inherit;\"><font style=\"vertical-align: inherit;\">faf</font></font></p>'),
(6, 'Terms', 'terms', '<p><label style=\"font-size: 30px; font-family: &quot;Visby Round Cf&quot;;\">1. Genel</label><br style=\"font-family: &quot;Visby Round Cf&quot;;\"><span style=\"font-family: &quot;Visby Round Cf&quot;;\">● Varsayılan minimum ödeme tutarı 5TL\'dir.</span><br style=\"font-family: &quot;Visby Round Cf&quot;;\"><span style=\"font-family: &quot;Visby Round Cf&quot;;\">● Atm ile bakiye yatıranlar kesintiyi karşılamalıdır, hesabımıza geçen ücret kadar bakiyeleri olacaktır.</span><br style=\"font-family: &quot;Visby Round Cf&quot;;\"><span style=\"font-family: &quot;Visby Round Cf&quot;;\">●&nbsp;</span><a href=\"https://takipcimedyasi.com/\" style=\"background-color: rgb(255, 255, 255); color: rgb(42, 100, 150); text-decoration-line: underline; outline: 0px;\">takipcimedyasi.com</a><span style=\"font-family: &quot;Visby Round Cf&quot;;\">&nbsp;servis fiyatlarını önceden haber vermeksizin herhangi bir zamanda değiştirebilir. Ödeme / Geri Ödeme politikası sabit kalır.</span><br style=\"font-family: &quot;Visby Round Cf&quot;;\"><span style=\"font-family: &quot;Visby Round Cf&quot;;\">●</span><a href=\"https://takipcimedyasi.com/\" style=\"background-color: rgb(255, 255, 255); color: rgb(42, 100, 150); text-decoration-line: underline; outline: 0px;\">takipcimedyasi.com</a><span style=\"font-family: &quot;Visby Round Cf&quot;;\">&nbsp;herhangi bir hizmet için teslimat süresini garanti etmez. Servislerde yazılı olan başlama süreleri belirttiğimiz en yakın tahminlerdir.</span><br style=\"font-family: &quot;Visby Round Cf&quot;;\"><span style=\"font-family: &quot;Visby Round Cf&quot;;\">● 1 Link için aynı anda sadece 1 sipariş girilebilir, 2 sipariş birden girildiğinde eksik gönderimler olabilir, sorumlusu&nbsp;</span><a href=\"https://takipcimedyasi.com/\" style=\"background-color: rgb(255, 255, 255); color: rgb(42, 100, 150); text-decoration-line: underline; outline: 0px;\">takipcimedyasi.com</a><span style=\"font-family: &quot;Visby Round Cf&quot;;\">&nbsp;değildir.</span><br style=\"font-family: &quot;Visby Round Cf&quot;;\"><span style=\"font-family: &quot;Visby Round Cf&quot;;\">●&nbsp;</span><a href=\"https://takipcimedyasi.com/\">takipcimedyasi.com</a>&nbsp;<span style=\"font-family: &quot;Visby Round Cf&quot;;\">Instagram, Facebook, Twitter veya sunduğu herhangi bir hizmet için, işlem yapılan hesabın askıya alınması, kapatılması gibi olası durumlarda mesuliyet kabul etmez.</span><br style=\"font-family: &quot;Visby Round Cf&quot;;\"><span style=\"font-family: &quot;Visby Round Cf&quot;;\">● Her servise verilen limit, hesap başına verilen limittir. Max 3k limitli bir servisten yararlanan hesap 4k çekim yapamaz.</span><br style=\"font-family: &quot;Visby Round Cf&quot;;\"><span style=\"font-family: &quot;Visby Round Cf&quot;;\">● Ürünlerin karşılarında belirtilen ücretler 1.000 (1K) ücretidir.</span><br style=\"font-family: &quot;Visby Round Cf&quot;;\"><span style=\"font-family: &quot;Visby Round Cf&quot;;\">● Sipariş girdiğiniz taktirde ürünün altındaki bilgilendirme varsa bilgilendirmeyi okumuş ve kabul etmiş olduğunuz anlamına gelir. Bu durum ile ilgili iade adminin insiyatifine bırakılmıştır.</span><br style=\"font-family: &quot;Visby Round Cf&quot;;\"><span style=\"font-family: &quot;Visby Round Cf&quot;;\">● </span><a href=\"https://takipcimedyasi.com/\" style=\"background-color: rgb(255, 255, 255); color: rgb(42, 100, 150); text-decoration-line: underline; outline: 0px;\">takipcimedyasi.com</a><span style=\"font-family: &quot;Visby Round Cf&quot;;\">\'dan aldığınız tüm hizmetler adınıza faturalandırılır. ●&nbsp;</span><br style=\"font-family: &quot;Visby Round Cf&quot;;\"><br style=\"font-family: &quot;Visby Round Cf&quot;;\"><br style=\"font-family: &quot;Visby Round Cf&quot;;\"><label style=\"font-size: 30px; font-family: &quot;Visby Round Cf&quot;;\">2. Hizmet</label><br style=\"font-family: &quot;Visby Round Cf&quot;;\"><span style=\"font-family: &quot;Visby Round Cf&quot;;\">●</span><a href=\"https://takipcimedyasi.com/\" style=\"background-color: rgb(255, 255, 255); color: rgb(42, 100, 150); text-decoration-line: underline; outline: 0px;\">takipcimedyasi.com</a><span style=\"font-family: &quot;Visby Round Cf&quot;;\">&nbsp;İnstagram/Twitter/Facebook veya başka bir Sosyal Medya hesabı için sadece \"Görünüm\" artırmaya yardımcı olmak için kullanılacaktır.</span><br style=\"font-family: &quot;Visby Round Cf&quot;;\"><span style=\"font-family: &quot;Visby Round Cf&quot;;\">●&nbsp;</span><a href=\"https://takipcimedyasi.com/\" style=\"background-color: rgb(255, 255, 255); color: rgb(42, 100, 150); text-decoration-line: underline; outline: 0px;\">takipcimedyasi.com</a><span style=\"font-family: &quot;Visby Round Cf&quot;;\">&nbsp;yeni takipçiler ve etkileşim garantisi vermez, sadece ödeme yapılarak alınan miktarı garanti eder.</span><br style=\"font-family: &quot;Visby Round Cf&quot;;\"><span style=\"font-family: &quot;Visby Round Cf&quot;;\">● Tüm bot hesapları gerçek görünüme dönüştürmek için çalışıyoruz, ancak hesaplarımızın %100 profil resimli, biyografili ve paylaşımlı hesaplar olacağının garantisini vermiyoruz.</span><br style=\"font-family: &quot;Visby Round Cf&quot;;\"><span style=\"font-family: &quot;Visby Round Cf&quot;;\">● Gizli hesaplara işlem yapıldığında sorumluluk üyeye aittir. Sipariş vermeden önce lütfen hesabın herkese açık olduğundan emin olun.</span><br style=\"font-family: &quot;Visby Round Cf&quot;;\"><br style=\"font-family: &quot;Visby Round Cf&quot;;\"><label style=\"font-size: 30px; font-family: &quot;Visby Round Cf&quot;;\">İade politikası</label><br style=\"font-family: &quot;Visby Round Cf&quot;;\"><span style=\"font-family: &quot;Visby Round Cf&quot;;\">● Yapılan ödemelerde geri iade mümkün değildir,&nbsp;</span><a href=\"https://takipcimedyasi.com/\" style=\"background-color: rgb(255, 255, 255); color: rgb(42, 100, 150); text-decoration-line: underline; outline: 0px;\">takipcimedyasi.com</a><span style=\"font-family: &quot;Visby Round Cf&quot;;\">&nbsp;hizmetlerinde kullanılması gerekir.</span><br style=\"font-family: &quot;Visby Round Cf&quot;;\"><span style=\"font-family: &quot;Visby Round Cf&quot;;\">● Instagram/Twitter/Facebook vb. servislerin ne zaman güncelleme yapabileceğini bilemeyiz, herhangi bir düşüş yaşanması halinde servis sağlayıcısı telafi yapmadığı sürece iade yapılamaz.</span><br style=\"font-family: &quot;Visby Round Cf&quot;;\"><span style=\"font-family: &quot;Visby Round Cf&quot;;\">● Siparişler sisteme girildikten sonra iptal/iade talebiniz kabul edilmeyecektir. Eğer sipariş tamamlanmazsa/kısmen tamamlanırsa sistem otomatik olarak geri ödeme yapacaktır.</span><br style=\"font-family: &quot;Visby Round Cf&quot;;\"><span style=\"font-family: &quot;Visby Round Cf&quot;;\">●</span><a href=\"https://takipcimedyasi.com/\" style=\"background-color: rgb(255, 255, 255); color: rgb(42, 100, 150); text-decoration-line: underline; outline: 0px;\">takipcimedyasi.com</a><span style=\"font-family: &quot;Visby Round Cf&quot;;\">&nbsp;yapılan ödemelerde herhangi bir ters ibraz, geri çekme söz konusu olursa üyeyi uzaklaştırma hakkını saklı tutar.</span><br style=\"font-family: &quot;Visby Round Cf&quot;;\"><span style=\"font-family: &quot;Visby Round Cf&quot;;\">● Yetkisiz işlem veya çalıntı kredi kartı, herhangi bir hileli faaliyette üye hesabı istisnasız kapatılacaktır.</span><br style=\"font-family: &quot;Visby Round Cf&quot;;\"><br style=\"font-family: &quot;Visby Round Cf&quot;;\"><br style=\"font-family: &quot;Visby Round Cf&quot;;\"><label style=\"font-size: 30px; font-family: &quot;Visby Round Cf&quot;;\">Gizlilik politikası</label><br style=\"font-family: &quot;Visby Round Cf&quot;;\"><span style=\"font-family: &quot;Visby Round Cf&quot;;\">● Bu politika kişisel bilgilerinizin nasıl kullanacağını kapsar. Gizliliğiniz bizim için önemlidir ve korumak için her türlü önlem alınmaktadır.</span><br style=\"font-family: &quot;Visby Round Cf&quot;;\"><span style=\"font-family: &quot;Visby Round Cf&quot;;\">● Sisteme girilen tüm bilgiler şifreli ve güvenli sunucularda barındırılır.</span><br style=\"font-family: &quot;Visby Round Cf&quot;;\"><span style=\"font-family: &quot;Visby Round Cf&quot;;\">● Bilgileriniz hiçbir şekilde 3. kişiler ile paylaşılmaz.</span><br style=\"font-family: &quot;Visby Round Cf&quot;;\"><span style=\"font-family: &quot;Visby Round Cf&quot;;\">● Firma tarafından kampanyalar hakkında bilgi sms gelebilmektedir</span><br></p>'),
(7, 'FAQ', 'faq', '<p>hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhooooooooooooooooo</p>'),
(8, 'Terms, FAQ', 'terms,faq', '<agrzm>'),
(9, 'Terms, FAQ', 'terms,faq', '<agrzm>');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `payment_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL DEFAULT 0,
  `client_balance` double NOT NULL DEFAULT 0,
  `payment_amount` double NOT NULL DEFAULT 0,
  `payment_privatecode` double DEFAULT NULL,
  `payment_method` int(11) NOT NULL DEFAULT -1,
  `payment_status` enum('1','2','3') NOT NULL DEFAULT '1',
  `payment_delivery` enum('1','2') NOT NULL DEFAULT '1',
  `payment_note` text DEFAULT NULL,
  `payment_mode` enum('Manuel','Otomatik') NOT NULL DEFAULT 'Otomatik',
  `payment_create_date` datetime NOT NULL DEFAULT current_timestamp(),
  `payment_update_date` datetime NOT NULL DEFAULT current_timestamp(),
  `payment_ip` varchar(225) DEFAULT NULL,
  `payment_extra` text DEFAULT NULL,
  `payment_bank` int(11) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`payment_id`, `client_id`, `client_balance`, `payment_amount`, `payment_privatecode`, `payment_method`, `payment_status`, `payment_delivery`, `payment_note`, `payment_mode`, `payment_create_date`, `payment_update_date`, `payment_ip`, `payment_extra`, `payment_bank`) VALUES
(1, 99, 0, 10, NULL, 13, '1', '1', NULL, 'Otomatik', '2021-01-02 11:27:01', '2021-01-02 11:27:01', '157.46.218.211', '356c1b064f73c497eb5f873e20e96493', 0),
(2, 99, 0, 10, NULL, 13, '1', '1', NULL, 'Otomatik', '2021-01-02 11:27:16', '2021-01-02 11:27:16', '157.46.218.211', '5b4634374f3d21e6903ba5ff2b771fa4', 0),
(3, 99, 0, 10, NULL, 13, '1', '1', NULL, 'Otomatik', '2021-01-02 11:34:08', '2021-01-02 11:34:08', '157.46.218.211', 'c2e03bf3ce4a2136096b81c5e5b7f6c2', 0),
(4, 99, 0, 1, NULL, 13, '1', '1', NULL, 'Otomatik', '2021-01-02 11:34:19', '2021-01-02 11:34:19', '157.46.218.211', '111a37f89ff189fdcd6803b6b0073f2b', 0),
(5, 99, 0, 1, NULL, 12, '1', '1', NULL, 'Otomatik', '2021-01-02 11:40:05', '2021-01-02 11:40:05', '157.46.218.211', 'ORDS11779', 0),
(9, 99, 0, 1, NULL, 13, '1', '1', NULL, 'Otomatik', '2021-01-02 11:47:42', '2021-01-02 11:47:42', '157.46.218.211', 'be2d4931cf9fb069c3fa137480519d15', 0),
(10, 99, 0, 1, NULL, 1, '1', '1', NULL, '', '2021-01-02 11:49:43', '2021-01-02 11:49:43', '157.46.218.211', 'a3a85806e3ad2e9b6e47c1a937269a3e', 0),
(11, 99, 0, 1, NULL, 15, '1', '1', NULL, 'Otomatik', '2021-01-02 11:50:07', '2021-01-02 11:50:07', '157.46.218.211', '1609568407', 0),
(12, 99, 0, 10, NULL, 15, '1', '1', NULL, 'Otomatik', '2021-01-02 11:50:48', '2021-01-02 11:50:48', '157.46.218.211', '1609568448', 0),
(13, 99, 0, 1, NULL, 13, '1', '1', NULL, 'Otomatik', '2021-01-02 11:51:25', '2021-01-02 11:51:25', '157.46.218.211', '212c417c403b16172a404c6fa5e4ccf7', 0),
(14, 99, 0, 1, NULL, 13, '1', '1', NULL, 'Otomatik', '2021-01-02 11:54:31', '2021-01-02 11:54:31', '157.46.218.211', 'accfa83cd7c1d7e675448b4dfefbf6ed', 0),
(15, 162, 0, 1, NULL, 13, '1', '1', NULL, 'Otomatik', '2021-01-09 12:00:44', '2021-01-09 12:00:44', '157.42.25.191', 'dd58bc4e0223433d6e27bfa8a38c7888', 0),
(16, 162, 0, 1, NULL, 12, '1', '1', NULL, 'Otomatik', '2021-01-09 12:01:04', '2021-01-09 12:01:04', '157.42.25.191', 'ORDS48203724', 0),
(17, 162, 0, 1, NULL, 1, '1', '1', NULL, '', '2021-01-09 12:01:32', '2021-01-09 12:01:32', '157.42.25.191', '53935e50823611adc250275a91e8c152', 0),
(18, 162, 0, 1, NULL, 13, '1', '1', NULL, 'Otomatik', '2021-01-09 12:01:53', '2021-01-09 12:01:53', '157.42.25.191', '6661e0f6784baec5f1a14ce4bc6c879e', 0),
(19, 99, 0, 20, NULL, 15, '1', '1', NULL, 'Otomatik', '2021-01-30 19:23:07', '2021-01-30 19:23:07', '::1', '1612014787', 0),
(20, 99, 0, 20, NULL, 9, '1', '1', NULL, '', '2021-01-30 19:23:30', '2021-01-30 19:23:30', '::1', 'dca335bee55d1f0276097a83802953e3', 0),
(21, 99, 0, 26, NULL, 12, '1', '1', NULL, 'Otomatik', '2021-01-30 19:23:57', '2021-01-30 19:23:57', '::1', 'ORDS12001877', 0),
(22, 99, 0, 34, NULL, 13, '1', '1', NULL, 'Otomatik', '2021-01-30 19:24:03', '2021-01-30 19:24:03', '::1', '16b1afd380908553f25a7afa56c82f7e', 0);

-- --------------------------------------------------------

--
-- Table structure for table `payments_bonus`
--

CREATE TABLE `payments_bonus` (
  `bonus_id` int(11) NOT NULL,
  `bonus_method` int(11) NOT NULL,
  `bonus_from` double NOT NULL,
  `bonus_amount` double NOT NULL,
  `bonus_type` enum('1','2') NOT NULL DEFAULT '2'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `payments_bonus`
--

INSERT INTO `payments_bonus` (`bonus_id`, `bonus_method`, `bonus_from`, `bonus_amount`, `bonus_type`) VALUES
(1, 15, 10, 5, '2');

-- --------------------------------------------------------

--
-- Table structure for table `payment_methods`
--

CREATE TABLE `payment_methods` (
  `id` int(11) NOT NULL,
  `method_name` varchar(225) NOT NULL,
  `method_get` varchar(225) NOT NULL,
  `method_min` double NOT NULL,
  `method_max` double NOT NULL,
  `method_type` enum('1','2') NOT NULL DEFAULT '2' COMMENT '2 -> ON, 1 -> OFF	',
  `method_extras` text NOT NULL,
  `method_line` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `payment_methods`
--

INSERT INTO `payment_methods` (`id`, `method_name`, `method_get`, `method_min`, `method_max`, `method_type`, `method_extras`, `method_line`) VALUES
(1, 'Paypal', 'paypal', 1, 0, '2', '{\"method_type\":\"2\",\"name\":\"Paypal\",\"min\":\"1\",\"max\":\"0\",\"client_id\":\"\",\"client_secret\":\"\",\"fee\":\"5\"}', 3),
(3, 'Shopier', 'shopier', 5, 0, '2', '{\"method_type\":\"2\",\"name\":\"Shopier\",\"min\":\"5\",\"max\":\"0\",\"apiKey\":\"\",\"apiSecret\":\"\",\"website_index\":\"1\",\"processing_fee\":\"1\",\"fee\":\"0\"}', 4),
(6, 'Manual Transfer(Bank)', 'havale-eft', 0, 0, '2', '{\"method_type\":\"1\",\"name\":\"Manual Transfer(Bank)\"}', 5),
(8, 'Coinpayments', 'coinpayments', 1, 0, '2', '{\"method_type\":\"2\",\"name\":\"Coinpayments\",\"min\":\"1\",\"max\":\"0\",\"coinpayments_public_key\":\"\",\"coinpayments_private_key\":\"\",\"coinpayments_currency\":\"BTC\",\"merchant_id\":\"\",\"ipn_secret\":\"\",\"fee\":\"0\"}', 6),
(9, '2checkout', '2checkout', 1, 0, '2', '{\"method_type\":\"2\",\"name\":\"2checkout\",\"min\":\"1\",\"max\":\"0\",\"seller_id\":\"\",\"private_key\":\"\",\"fee\":\"0\"}', 7),
(10, 'Payoneer', 'payoneer', 0, 0, '2', '{\"method_type\":\"2\",\"name\":\"Payoneer\",\"email\":\"admin@gmail.com\"}', 8),
(11, 'Mollie', 'mollie', 1, 0, '2', '{\"method_type\":\"2\",\"name\":\"Mollie\",\"min\":\"1\",\"max\":\"0\",\"live_api_key\":\"\",\"fee\":\"0\"}', 9),
(12, 'PayTM', 'paytm', 1, 10000, '2', '{\"method_type\":\"2\",\"name\":\"PayTM\",\"min\":\"1\",\"max\":\"10000\",\"merchant_key\":\"\",\"merchant_mid\":\"\",\"merchant_website\":\"DEFAULT\",\"fee\":\"0\"}', 2),
(13, 'RazorPay', 'razorpay', 1, 0, '2', '{\"method_type\":\"2\",\"name\":\"Razorpay\",\"min\":\"1\",\"max\":\"0\",\"public_key\":\"\",\"key_secret\":\"\",\"merchant_website\":\"https:\\/\\/api.razorpay.com\\/v1\\/orders\",\"fee\":\"0\"}', 1),
(14, 'PayTM QR', 'paytmqr', 1, 0, '2', '{\"method_type\":\"2\",\"name\":\"PayTMQR\",\"min\":\"1\",\"max\":\"0\",\"merchant_key\":\"\\/img\\/paytm_qr.png\",\"merchant_mid\":\"\",\"merchant_website\":\"DEFAULT\",\"fee\":\"0\"}', 10),
(15, 'Perfect Money', 'perfectmoney', 0, 10000, '2', '{\"method_type\":\"2\",\"name\":\"Perfect Money\",\"min\":\"0\",\"max\":\"10000\",\"passphrase\":\"\",\"usd\":\"\",\"merchant_website\":\"\",\"fee\":\"0\"}', 10);

-- --------------------------------------------------------

--
-- Table structure for table `serviceapi_alert`
--

CREATE TABLE `serviceapi_alert` (
  `id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL,
  `serviceapi_alert` text NOT NULL,
  `servicealert_extra` text NOT NULL,
  `servicealert_date` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `service_id` int(11) NOT NULL,
  `service_api` int(11) NOT NULL DEFAULT 0,
  `api_service` int(11) NOT NULL DEFAULT 0,
  `api_servicetype` enum('1','2') NOT NULL DEFAULT '2',
  `api_detail` text NOT NULL,
  `category_id` int(11) NOT NULL,
  `service_line` double NOT NULL,
  `service_type` enum('1','2') NOT NULL DEFAULT '2',
  `service_package` enum('1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17') NOT NULL,
  `service_name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `service_description` text DEFAULT NULL,
  `service_price` double NOT NULL DEFAULT 0,
  `service_min` double NOT NULL,
  `service_max` double NOT NULL,
  `service_dripfeed` enum('1','2') NOT NULL DEFAULT '1',
  `service_autotime` double NOT NULL DEFAULT 0,
  `service_autopost` double NOT NULL DEFAULT 0,
  `service_speed` enum('1','2','3','4') NOT NULL,
  `want_username` enum('1','2') NOT NULL DEFAULT '1',
  `service_secret` enum('1','2') NOT NULL DEFAULT '2',
  `price_type` enum('normal','percent','amount') NOT NULL DEFAULT 'normal',
  `price_cal` text DEFAULT NULL,
  `instagram_second` enum('1','2') NOT NULL DEFAULT '2',
  `start_count` enum('none','instagram_follower','instagram_photo','') NOT NULL,
  `instagram_private` enum('1','2') NOT NULL,
  `name_lang` text DEFAULT NULL,
  `description_lang` text DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`service_id`, `service_api`, `api_service`, `api_servicetype`, `api_detail`, `category_id`, `service_line`, `service_type`, `service_package`, `service_name`, `service_description`, `service_price`, `service_min`, `service_max`, `service_dripfeed`, `service_autotime`, `service_autopost`, `service_speed`, `want_username`, `service_secret`, `price_type`, `price_cal`, `instagram_second`, `start_count`, `instagram_private`, `name_lang`, `description_lang`) VALUES
(1, 0, 0, '2', '', 1, 1, '2', '1', 'Panel Testing Service [ ALL GOOD :) ]', 'Test Service', 1000, 100, 2600, '1', 0, 0, '1', '2', '2', 'normal', NULL, '2', 'instagram_follower', '2', '\"Panel Testing Service [ ALL GOOD :) ]\"', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `service_api`
--

CREATE TABLE `service_api` (
  `id` int(11) NOT NULL,
  `api_name` varchar(225) NOT NULL,
  `api_url` text NOT NULL,
  `api_key` varchar(225) NOT NULL,
  `api_type` int(11) NOT NULL,
  `api_limit` double NOT NULL DEFAULT 0,
  `currency` enum('INR','USD') DEFAULT NULL,
  `api_alert` enum('1','2') NOT NULL DEFAULT '2' COMMENT '2 -> Gönder, 1 -> Gönderildi'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(11) NOT NULL,
  `site_seo` text NOT NULL,
  `site_title` text DEFAULT NULL,
  `site_description` text DEFAULT NULL,
  `site_keywords` text DEFAULT NULL,
  `site_logo` text DEFAULT NULL,
  `site_name` text DEFAULT NULL,
  `site_currency` varchar(2555) NOT NULL DEFAULT 'try',
  `favicon` text DEFAULT NULL,
  `site_language` varchar(225) NOT NULL DEFAULT 'tr',
  `site_theme` text NOT NULL,
  `site_theme_alt` text DEFAULT NULL,
  `recaptcha` enum('1','2') NOT NULL DEFAULT '1',
  `recaptcha_key` text DEFAULT NULL,
  `recaptcha_secret` text DEFAULT NULL,
  `custom_header` text DEFAULT NULL,
  `custom_footer` text DEFAULT NULL,
  `ticket_system` enum('1','2') NOT NULL DEFAULT '2',
  `register_page` enum('1','2') NOT NULL DEFAULT '2',
  `service_speed` enum('1','2') NOT NULL,
  `service_list` enum('1','2') NOT NULL,
  `dolar_charge` double NOT NULL,
  `euro_charge` double NOT NULL,
  `smtp_user` text NOT NULL,
  `smtp_pass` text NOT NULL,
  `smtp_server` text NOT NULL,
  `smtp_port` varchar(225) NOT NULL,
  `smtp_protocol` enum('0','ssl','tls') NOT NULL,
  `alert_type` enum('1','2','3') NOT NULL,
  `alert_newbankpayment` enum('1','2') NOT NULL,
  `alert_newmanuelservice` enum('1','2') NOT NULL,
  `alert_newticket` enum('1','2') NOT NULL,
  `alert_apibalance` enum('1','2') NOT NULL,
  `alert_serviceapialert` enum('1','2') NOT NULL,
  `sms_provider` varchar(225) NOT NULL,
  `sms_title` varchar(225) NOT NULL,
  `sms_user` varchar(225) NOT NULL,
  `sms_pass` varchar(225) NOT NULL,
  `sms_validate` enum('0','1') NOT NULL DEFAULT '0' COMMENT '1 -> OK, 0 -> NO',
  `admin_mail` varchar(225) NOT NULL,
  `admin_telephone` varchar(225) NOT NULL,
  `resetpass_page` enum('1','2') NOT NULL,
  `resetpass_sms` enum('1','2') NOT NULL,
  `resetpass_email` enum('1','2') NOT NULL,
  `site_maintenance` enum('1','2') NOT NULL DEFAULT '2',
  `servis_siralama` varchar(255) NOT NULL,
  `bronz_statu` int(11) NOT NULL,
  `silver_statu` int(11) NOT NULL,
  `gold_statu` int(11) NOT NULL,
  `bayi_statu` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `site_seo`, `site_title`, `site_description`, `site_keywords`, `site_logo`, `site_name`, `site_currency`, `favicon`, `site_language`, `site_theme`, `site_theme_alt`, `recaptcha`, `recaptcha_key`, `recaptcha_secret`, `custom_header`, `custom_footer`, `ticket_system`, `register_page`, `service_speed`, `service_list`, `dolar_charge`, `euro_charge`, `smtp_user`, `smtp_pass`, `smtp_server`, `smtp_port`, `smtp_protocol`, `alert_type`, `alert_newbankpayment`, `alert_newmanuelservice`, `alert_newticket`, `alert_apibalance`, `alert_serviceapialert`, `sms_provider`, `sms_title`, `sms_user`, `sms_pass`, `sms_validate`, `admin_mail`, `admin_telephone`, `resetpass_page`, `resetpass_sms`, `resetpass_email`, `site_maintenance`, `servis_siralama`, `bronz_statu`, `silver_statu`, `gold_statu`, `bayi_statu`) VALUES
(1, 'Perfect Panel Script | SMMPanels.Store', 'Perfect Panel Script | SMMPanels.Store', '', 'Perfect Panel Script | SMMPanels.Store', 'public/images/f4f6dce2f3a0f9dada0c2b5b66452017.png', 'Perfect Panel Script | SMMPanels.Store', 'USD', 'public/images/c70dfb07dc67c9dd6a8bc01130acf68d1fbf035f.png', 'en', 'modern', 'Lightblue', '1', '', '', '', '', '2', '2', '1', '2', 76, 76, 'admin@smmpanels.store', '1234567890', 'mail.smmpanels.store', '465', 'ssl', '1', '2', '2', '2', '2', '1', 'bizimsms', 'smmpanels.store', 'smmpanels.store', 'smmpanels.store', '1', 'admin@smmpanels.store', '1234567890', '2', '1', '2', '2', 'desc', 2147483647, 2147483647, 2147483647, 52);

-- --------------------------------------------------------

--
-- Table structure for table `themes`
--

CREATE TABLE `themes` (
  `id` int(11) NOT NULL,
  `theme_name` text NOT NULL,
  `theme_dirname` text NOT NULL,
  `theme_extras` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `themes`
--

INSERT INTO `themes` (`id`, `theme_name`, `theme_dirname`, `theme_extras`) VALUES
(1, 'Classic', 'bootstrap', '{\"stylesheets\":[\"/public/bootstrap/style.css\",\"https:\\/\\/stackpath.bootstrapcdn.com\\/font-awesome\\/4.7.0\\/css\\/font-awesome.min.css\",\"/public\\/datepicker\\/css\\/bootstrap-datepicker3.min.css\"],\"scripts\":[\"https:\\/\\/code.jquery.com\\/jquery-3.3.1.min.js\",\"/public/bootstrap/script.js\",\"/public/ajax.js\",\"/public/bootstrap/bootstrap.js\",\"/public\\/datepicker\\/js\\/bootstrap-datepicker.min.js\",\"/public\\/datepicker\\/locales\\/bootstrap-datepicker.tr.min.js\"]}'),
(3, 'Darker', 'darker', '{\"stylesheets\":[\"/public/darker/bootstrap.css\",\"/public/darker/style.css\",\"https:\\/\\/stackpath.bootstrapcdn.com\\/font-awesome\\/4.7.0\\/css\\/font-awesome.min.css\",\"/public\\/datepicker\\/css\\/bootstrap-datepicker3.min.css\"],\"scripts\":[\"https:\\/\\/code.jquery.com\\/jquery-3.3.1.min.js\",\"/public/darker/script.js\",\"public/ajax.js\",\"/public/darker/bootstrap.js\",\"public\\/datepicker\\/js\\/bootstrap-datepicker.min.js\",\"/public\\/datepicker\\/locales\\/bootstrap-datepicker.tr.min.js\"]}'),
(4, 'İpek', 'ipek', '{\"stylesheets\":[\"public/ipek/bootstrap.css\",\"public/ipek/style.css\",\"https:\\/\\/stackpath.bootstrapcdn.com\\/font-awesome\\/4.7.0\\/css\\/font-awesome.min.css\",\"public\\/datepicker\\/css\\/bootstrap-datepicker3.min.css\"],\"scripts\":[\"https:\\/\\/code.jquery.com\\/jquery-3.3.1.min.js\",\"public/ipek/script.js\",\"public/ajax.js\",\"public/ipek/bootstrap.js\",\"public\\/datepicker\\/js\\/bootstrap-datepicker.min.js\",\"public\\/datepicker\\/locales\\/bootstrap-datepicker.tr.min.js\"]}'),
(10, 'Modern', 'modern', ''),
(6, 'Elites', 'elites', '{\"stylesheets\":[\"public/elites/bootstrap.css\",\"public/elites/style.css\",\"https:\\/\\/stackpath.bootstrapcdn.com\\/font-awesome\\/4.7.0\\/css\\/font-awesome.min.css\",\"public\\/datepicker\\/css\\/bootstrap-datepicker3.min.css\"],\"scripts\":[\"https:\\/\\/code.jquery.com\\/jquery-3.3.1.min.js\",\"public/elites/script.js\",\"public/ajax.js\",\"public/elites/bootstrap.js\",\"public\\/datepicker\\/js\\/bootstrap-datepicker.min.js\",\"public\\/datepicker\\/locales\\/bootstrap-datepicker.tr.min.js\"]}'),
(7, 'Murky', 'murky', '{\"stylesheets\":[\"public/murky/bootstrap.css\",\"public/murky/style.css\",\"https:\\/\\/stackpath.bootstrapcdn.com\\/font-awesome\\/4.7.0\\/css\\/font-awesome.min.css\",\"public\\/datepicker\\/css\\/bootstrap-datepicker3.min.css\"],\"scripts\":[\"https:\\/\\/code.jquery.com\\/jquery-3.3.1.min.js\",\"public/murky/script.js\",\"public/ajax.js\",\"public/murky/bootstrap.js\",\"public\\/datepicker\\/js\\/bootstrap-datepicker.min.js\",\"public\\/datepicker\\/locales\\/bootstrap-datepicker.tr.min.js\"]}'),
(8, 'Sunlit', 'sunlit', '{\"stylesheets\":[\"public/sunlit/bootstrap.css\",\"public/sunlit/style.css\",\"https:\\/\\/stackpath.bootstrapcdn.com\\/font-awesome\\/4.7.0\\/css\\/font-awesome.min.css\",\"public\\/datepicker\\/css\\/bootstrap-datepicker3.min.css\"],\"scripts\":[\"https:\\/\\/code.jquery.com\\/jquery-3.3.1.min.js\",\"public/sunlit/script.js\",\"public/ajax.js\",\"public/sunlit/bootstrap.js\",\"public\\/datepicker\\/js\\/bootstrap-datepicker.min.js\",\"public\\/datepicker\\/locales\\/bootstrap-datepicker.tr.min.js\"]}'),
(9, 'Agrzm', 'Agrzm', '{\"stylesheets\":[\"public/Agrzm/bootstrap.css\",\"public/Agrzm/style.css\",\"https:\\/\\/stackpath.bootstrapcdn.com\\/font-awesome\\/4.7.0\\/css\\/font-awesome.min.css\",\"public\\/datepicker\\/css\\/bootstrap-datepicker3.min.css\"],\"scripts\":[\"https:\\/\\/code.jquery.com\\/jquery-3.3.1.min.js\",\"public/Agrzm/script.js\",\"public/ajax.js\",\"public/Agrzm/bootstrap.js\",\"public\\/datepicker\\/js\\/bootstrap-datepicker.min.js\",\"public\\/datepicker\\/locales\\/bootstrap-datepicker.tr.min.js\"]}');

-- --------------------------------------------------------

--
-- Table structure for table `tickets`
--

CREATE TABLE `tickets` (
  `ticket_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `subject` varchar(225) NOT NULL,
  `time` datetime NOT NULL,
  `lastupdate_time` datetime NOT NULL,
  `client_new` enum('1','2') NOT NULL DEFAULT '2',
  `status` enum('pending','answered','closed') NOT NULL DEFAULT 'pending',
  `support_new` enum('1','2') NOT NULL DEFAULT '1',
  `canmessage` enum('1','2') NOT NULL DEFAULT '2'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `ticket_reply`
--

CREATE TABLE `ticket_reply` (
  `id` int(11) NOT NULL,
  `ticket_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `time` datetime NOT NULL DEFAULT current_timestamp(),
  `support` enum('1','2') NOT NULL DEFAULT '1',
  `message` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bank_accounts`
--
ALTER TABLE `bank_accounts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`client_id`);

--
-- Indexes for table `clients_category`
--
ALTER TABLE `clients_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `clients_price`
--
ALTER TABLE `clients_price`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `clients_service`
--
ALTER TABLE `clients_service`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `client_report`
--
ALTER TABLE `client_report`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `kuponlar`
--
ALTER TABLE `kuponlar`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `kupon_kullananlar`
--
ALTER TABLE `kupon_kullananlar`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `languages`
--
ALTER TABLE `languages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`page_id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`payment_id`);

--
-- Indexes for table `payments_bonus`
--
ALTER TABLE `payments_bonus`
  ADD PRIMARY KEY (`bonus_id`);

--
-- Indexes for table `payment_methods`
--
ALTER TABLE `payment_methods`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `serviceapi_alert`
--
ALTER TABLE `serviceapi_alert`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`service_id`);

--
-- Indexes for table `service_api`
--
ALTER TABLE `service_api`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `themes`
--
ALTER TABLE `themes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tickets`
--
ALTER TABLE `tickets`
  ADD PRIMARY KEY (`ticket_id`);

--
-- Indexes for table `ticket_reply`
--
ALTER TABLE `ticket_reply`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bank_accounts`
--
ALTER TABLE `bank_accounts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `clients`
--
ALTER TABLE `clients`
  MODIFY `client_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=171;

--
-- AUTO_INCREMENT for table `clients_category`
--
ALTER TABLE `clients_category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `clients_price`
--
ALTER TABLE `clients_price`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `clients_service`
--
ALTER TABLE `clients_service`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `client_report`
--
ALTER TABLE `client_report`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=87;

--
-- AUTO_INCREMENT for table `kuponlar`
--
ALTER TABLE `kuponlar`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `kupon_kullananlar`
--
ALTER TABLE `kupon_kullananlar`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `languages`
--
ALTER TABLE `languages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pages`
--
ALTER TABLE `pages`
  MODIFY `page_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `payment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `payments_bonus`
--
ALTER TABLE `payments_bonus`
  MODIFY `bonus_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `serviceapi_alert`
--
ALTER TABLE `serviceapi_alert`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `service_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `service_api`
--
ALTER TABLE `service_api`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `themes`
--
ALTER TABLE `themes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `tickets`
--
ALTER TABLE `tickets`
  MODIFY `ticket_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `ticket_reply`
--
ALTER TABLE `ticket_reply`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
